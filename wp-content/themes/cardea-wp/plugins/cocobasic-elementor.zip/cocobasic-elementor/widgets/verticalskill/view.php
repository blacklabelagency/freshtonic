 
<div class="v-skills-holder">
    <?php echo $this->content($settings['items']);?> 
</div>

