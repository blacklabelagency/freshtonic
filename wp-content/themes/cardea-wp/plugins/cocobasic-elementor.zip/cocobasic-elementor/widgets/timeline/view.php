 
 
<ul class="timeline-holder">
    <?php echo $this->content($settings['items']);?> 
</ul>

